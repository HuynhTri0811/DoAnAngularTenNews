import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-more-news-area',
  templateUrl: './more-news-area.component.html',
  styleUrls: ['./more-news-area.component.css']
})
export class MoreNewsAreaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
