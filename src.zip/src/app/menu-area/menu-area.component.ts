import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-area',
  templateUrl: './menu-area.component.html',
  styleUrls: ['./menu-area.component.css']
})
export class MenuAreaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
