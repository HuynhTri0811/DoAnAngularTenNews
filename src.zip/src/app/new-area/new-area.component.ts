import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-area',
  templateUrl: './new-area.component.html',
  styleUrls: ['./new-area.component.css']
})
export class NewAreaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
