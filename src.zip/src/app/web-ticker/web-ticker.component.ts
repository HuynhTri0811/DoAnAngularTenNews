import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-web-ticker',
  templateUrl: './web-ticker.component.html',
  styleUrls: ['./web-ticker.component.css']
})
export class WebTickerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
