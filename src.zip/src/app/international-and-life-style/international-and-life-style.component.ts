import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-international-and-life-style',
  templateUrl: './international-and-life-style.component.html',
  styleUrls: ['./international-and-life-style.component.css']
})
export class InternationalAndLifeStyleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
