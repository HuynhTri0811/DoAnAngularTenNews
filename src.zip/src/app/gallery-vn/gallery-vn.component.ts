import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery-vn',
  templateUrl: './gallery-vn.component.html',
  styleUrls: ['./gallery-vn.component.css']
})
export class GalleryVnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
