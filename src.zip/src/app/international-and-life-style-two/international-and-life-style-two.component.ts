import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-international-and-life-style-two',
  templateUrl: './international-and-life-style-two.component.html',
  styleUrls: ['./international-and-life-style-two.component.css']
})
export class InternationalAndLifeStyleTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
